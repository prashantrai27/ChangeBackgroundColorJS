var a = document.getElementById("demo");
a.addEventListener("click",function(){
    const color = ["pink","red","violet","blue","yellow","orange","green","grey"];
    const random = Math.floor(Math.random() * color.length);
    document.body.style.background = color[random];
})

